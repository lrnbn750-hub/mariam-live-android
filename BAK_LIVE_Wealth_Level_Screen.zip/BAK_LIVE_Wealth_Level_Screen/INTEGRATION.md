# إعادة تصميم صفحة "مستوى الثراء" (BAK LIVE)

صفحة جديدة بنفس هوية شارات المستوى: نفس الفئات العشر والألوان والأيقونات في كل مكان.
لم يصلني كود الصفحة الحالية، لذلك التسليم **مكوّنات جاهزة** + خطوات ربط. لم أعدّل أي ملف موجود.

## ما الجديد
- **بطاقة رئيسية**: ميدالية المستوى الكبيرة بلون الفئة (للمستوى 91+ أشعة ذهبية دوّارة وبريق)، رقم LV بتدرج لوني،
  اسم الرتبة، نقاط الخبرة، شريط تقدم بلون الفئة مع لمعان وتوهج عند الطرف، وسطر المتبقي من XP.
- **مسار الرتب** (10 مراحل): كل بطاقة فيها ميدالية الفئة، الاسم، نطاق المستويات، 10 خطوات تقدم، وحالة:
  مكتملة (أخضر) / رتبتك الحالية (تتوهج بلون الفئة مع تقدمك داخلها) / مقفلة (باهتة مع قفل).
- يعمل RTL تلقائياً (الميدالية يمين، الحالة يسار، شريط التقدم يمتلئ من اليمين).

## الملفات (كلها جديدة) — الجذر `app/src/main/`
| المسار | الغرض |
|---|---|
| `java/com/mariam/live/LevelTiers.kt` | بيانات الفئات والألوان وأسماؤها (مصدر واحد) |
| `java/com/mariam/live/LevelEmblemView.kt` | الميدالية الكبيرة (+ الرسّام المشترك) |
| `java/com/mariam/live/LevelProgressBarView.kt` | شريط التقدم |
| `java/com/mariam/live/RankTierRowView.kt` | صف مرحلة في المسار |
| `java/com/mariam/live/WealthLevelHeroView.kt` | البطاقة الرئيسية |
| `java/com/mariam/live/WealthLevelContentView.kt` | كامل محتوى الصفحة (البطاقة + المسار) |
| `res/layout/view_wealth_level_hero.xml` · `view_wealth_level_content.xml` | تخطيطات المكوّنات |
| `res/layout/wealth_level_screen.xml` | تخطيط شاشة كامل **اختياري** (شريط علوي + ScrollView) |
| `res/drawable/wealth_ic_back.xml` | سهم الرجوع (ينعكس تلقائياً في RTL) |
| `res/values/` و`res/values-ar/` → `wealth_level_strings.xml` | النصوص (عربي + إنجليزي) |

بلا مكتبات إضافية. الحزمة `com.mariam.live` (غيّر سطر package فقط إن اختلفت). كل الأسماء بسابقة wealth_/Level... لتجنب التعارض.

## الربط (استبدل واجهة الصفحة القديمة فقط، وأبقِ منطق التحميل والـAPI كما هو)
```kotlin
val content = findViewById<WealthLevelContentView>(R.id.wealthContent)   // أو ضعه داخل الـScrollView الحالي

content.bind(
    level = user.level,            // 1..100 (القيمة الحقيقية)
    totalXp = user.totalXp,        // Long
    progress = user.progress,      // 0f..1f  (1f عند المستوى 100)
    remainingXp = user.xpToNext    // Long? — null يخفي سطر "باقي XP"
)
content.onTierClick = { tierIndex -> /* اختياري */ }
```

## شريط الحالة (مشكلة في الصفحة الحالية)
العنوان وسهم الرجوع كانا يتداخلان مع الساعة والبطارية. أعطِ الشريط العلوي padding بارتفاع شريط الحالة:
```kotlin
findViewById<View>(R.id.wealthToolbar).setOnApplyWindowInsetsListener { v, insets ->
    val top = if (android.os.Build.VERSION.SDK_INT >= 30)
        insets.getInsets(android.view.WindowInsets.Type.statusBars()).top
    else @Suppress("DEPRECATION") insets.systemWindowInsetTop
    v.setPadding(v.paddingLeft, top, v.paddingRight, v.paddingBottom)
    insets
}
```
(اربط أزرار الرجوع والأيقونة اليمنى الحالية بنفس معالجاتها.)

## أسماء الرتب — تغيير مقصود
لتتطابق مع ألوان الشارات صارت الأسماء: الفولاذي 1–10 · الزمردي 11–20 · الفيروزي 21–30 · الياقوتي 31–40 ·
الجمشتي 41–50 · الوردي 51–60 · الناري 61–70 · الذهبي 71–80 · البلاتيني 81–90 · الملكي 91–100.
(الأسماء القديمة: برونزي، فضي، ذهبي، زمردي...). تعديل أي اسم من مكان واحد: `LevelTiers.kt`.

## ما لم يُلمس
أي API أو بيانات أو منطق XP، أو صفحة أخرى، أو Gradle. المكوّنات تعرض ما تعطيها فقط.

## المعاينة (`preview/`)
مستوى 100 ومستوى 37 (تقدم 62% ومرحلة حالية). مرسومة بمحاكاة JavaScript Canvas مطابقة للكود (نفس الألوان والأبعاد والمنطق)،
وليست لقطة من جهاز؛ خط الهاتف يختلف قليلاً عن خط المعاينة.
