# BAK LIVE VIP asset merge patch

Staged Android assets for VIP 1-12.
- app/src/main/res/drawable-nodpi: 60 PNG resources (frames, badges, icons, particles, Nine-Patch bubbles)
- app/src/main/res/raw: 24 Lottie JSON animations
- app/src/main/assets/vip_levels: complete original per-level assets
- app/src/main/assets/vip_levels_manifest.json: palette and bubble text colors
- app/src/main/java/com/mariam/live/VipAssetResources.kt: helper to resolve resources by VIP level

This patch does not change purchase, wallet, membership, or backend logic. UI call sites still need to use these resources after reading the active VIP level from the backend.
